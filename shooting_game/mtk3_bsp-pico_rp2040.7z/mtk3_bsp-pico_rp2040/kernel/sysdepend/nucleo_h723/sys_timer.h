/*
 *----------------------------------------------------------------------
 *    micro T-Kernel 3.0 BSP
 *
 *    Copyright (C) 2022 by Ken Sakamura.
 *    This software is distributed under the T-License 2.2.
 *----------------------------------------------------------------------
 *
 *    Released by TRON Forum(http://www.tron.org) at 2022/02.
 *
 *----------------------------------------------------------------------
 */

/*
 *	sys_timer.h (Nucleo-144 STM32H723)
 *	Hardware-Dependent System Timer Processing
 */

#ifndef _SYSDEPEND_TARGET_SYSTIMER_
#define _SYSDEPEND_TARGET_SYSTIMER_

#include "../cpu/stm32h7/sys_timer.h"

#endif /* _SYSDEPEND_TARGET_SYSTIMER_ */