/*
 *----------------------------------------------------------------------
 *    micro T-Kernel 3.0 BSP
 *
 *    Copyright (C) 2022-2023 by Ken Sakamura.
 *    This software is distributed under the T-License 2.2.
 *----------------------------------------------------------------------
 *
 *    Released by TRON Forum(http://www.tron.org) at 2023/05.
 *
 *----------------------------------------------------------------------
 */

/*
 *	app_main.c
 *	Application main program for RaspberryPi Pico
 */

#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include <bsp/libbsp.h>
#include <sys/queue.h>
#include <../kernel/tkernel/timer.h>

#include "gpio/gpio_rp2040.h"
#include "ole/ole.h"
#include "ole/graph.h"
#include "gpio/address_mapped.h"
#include "gpio/addressmap.h"
#include "debounce/db.h"
#include "char/char.h"
#include "app_main.h"
#include "joy/joy.h"

#define INIT_OBJ(a)		memset((a), 0x0, sizeof((a)))

extern void *memset(void *s, int c, size_t n);

LOCAL void task_disp(INT stacd, void *exinf);	// 実行関数
LOCAL ID	tskid_disp;			// ID番号
LOCAL ID CCYC1; //SWの検出cycle(1ms)
LOCAL ID CCYC2; //ゲームcycle(20ms)

LOCAL UB polxy[SHIP_POLNUM*2] = {0,0, 1,SHIP_HEIGHT-1, SHIP_WIDTH-1,SHIP_HEIGHT-1 };
LOCAL alien_t ali[ALIEN_NUM];
LOCAL miss_t miss[MISS_NUM];
LOCAL ship_t ship;

LOCAL UW score;
LOCAL UW g_cnt = 0;
LOCAL B	stage = 0;

LOCAL UW get_random(void)
{
	UW val = 0;
	for (int i=0; i<32; i++) {
	  val |= (*(io_rw_32 *)(ROSC_BASE | 0x1c)) & 1;
	  val <<= 1;
	}
	return val;
}
LOCAL void cyc_cb(void *exinf)
{
	for (int i=GP_SW_START; i < GP_SW_START+GP_SW_NUM; i++) {
		db_set_val(i, gpio_get_val(i));
	}
}
LOCAL void cyc_cb2(void *exinf)
{
	tk_wup_tsk(tskid_disp);
}
LOCAL void sw_task_init(void)
{
	static T_CCYC ccyc = {	// check input / 10 msec
			.exinf = NULL,		/* Extended information */
			.cycatr = TA_STA,	/* Cycle handler attribute */
			.cychdr = cyc_cb,	/* Cycle handler address */
			.cyctim = 10,		/* Cycle interval */
			.cycphs = 10,		/* Cycle phase */
	};

	//GPIO IN設定 SIOはset_wは効果なし
	/* The SIO (Section 2.3.1), a single-cycle IO block attached directly
	to the cores' IO ports, does not support atomic accesses at the bus level,
	although some individual registers (e.g. GPIO) have set/clear/xor aliases.
	*/
	for (int i=GP_SW_START; i<GP_SW_START+GP_SW_NUM; i++) {
		gpio_set_pin(i, GPIO_MODE_IN);
		//pull up
		out_w(GPIO(i), GPIO_OD | GPIO_IE | GPIO_DRIVE_4MA | GPIO_PUE | GPIO_SHEMITT);
	}
	//debounce
	db_init(GP_SW_START, GP_SW_NUM);
	CCYC1 = tk_cre_cyc(&ccyc);

	//get val
	static T_CCYC ccyc2 = {	// get value / 100 msec
			.exinf = NULL,		/* Extended information */
			.cycatr = TA_STA,	/* Cycle handler attribute */
			.cychdr = cyc_cb2,	/* Cycle handler address */
			.cyctim = 50,		/* Cycle interval */
			.cycphs = 50,		/* Cycle phase */
	};
	CCYC2 = tk_cre_cyc(&ccyc2);
}

LOCAL void update_kabe()
{
	static UB len[2] = {0,0};
	static BOOL dir[2] = {TRUE, TRUE};
	static UW cnt = 0;

	pix_scroll_x(PLN_KABE);
	//star
	if (stage == 0) {
		UW r = get_random();
		UW r1 = r & 0xffff;
		UW r2 = r >> 16;
		if (0 == (r1 % 10)) { //出現確率
			pix_set(PLN_KABE, OLE_W-1, r2 % KABE_TAKASA);//KABEは、SRG1～7を使用
		}
		return;
	}
	//kabe
	for (int i=0; i<2; i++) {
		UW val = get_random();
		val %= 10;
		if (val) {
			if (dir[i]) {	//上り下りの維持
				len[i]++;
				if (len[i] > DOKU_H) len[i] = DOKU_H;
			} else {
				if (len[i]>0) len[i]--;
			}
		} else { //上り下り反転
			dir[i] = dir[i] ? FALSE:TRUE;
		}
		if (i == 0) {
			pix_line(PLN_KABE, OLE_W-1,0, OLE_W-1, len[i]);
			pix_mask_kabe(cnt, OLE_W-1,0, len[i]);
		} else {
			pix_line(PLN_KABE, OLE_W-1,KABE_TAKASA-1, OLE_W-1, KABE_TAKASA-1-len[i]);
			pix_mask_kabe(cnt, OLE_W-1,KABE_TAKASA-1, KABE_TAKASA-1-len[i]);
		}
	}
	cnt++;
}

LOCAL void ship_set(UB x, UB y)
{
	pix_ship( (g_cnt/20) % 2, x, y);
}
//missile と alien との当たり検出
LOCAL void miss_atari(void)
{
	for (int i=0; i < MISS_NUM; i++) {
		if (!miss[i].exist) continue;
		for (int j=0; j < ALIEN_NUM; j++) {
			if (!ali[j].exist) continue;
			if (ali[j].x+ALIEN_WIDTH >= miss[i].x-MISS_LEN && ali[j].x <= miss[i].x &&
					(ali[j].y <= miss[i].y && ali[j].y+ALIEN_HEIGHT > miss[i].y)) {
				miss[j].exist = FALSE;
				ali[j].exist = FALSE;
				if (ali[j].bonus) {
					score+=400;
				} else {
					score+=100;
				}
				continue;
			}
		}
	}
}
LOCAL BOOL atari(UB x, UB y)
{
	B skip = TRUE;
	// change stage for atari hantei
	//stage 0:star(skip), 1:kabe(no skip)
	if (stage==1 && (g_cnt % STAGE_TICKS) > (OLE_W - (x+SHIP_WIDTH)) ) skip=FALSE;
	if (stage==0 && (g_cnt % STAGE_TICKS) < (OLE_W - (x+SHIP_WIDTH)) ) skip=FALSE;
	//SHIPのpolygon頂点での重なり参照
	for (int i=0; i < SHIP_POLNUM; i++) {
		if (pix_exist(PLN_ALIEN, polxy[i*2]+x, polxy[i*2+1]+y)) {
			return TRUE;
		}
		if (skip) continue;
		if (pix_exist(PLN_KABE, polxy[i*2]+x, polxy[i*2+1]+y)) {
			return TRUE;
		}
	}
	return FALSE;
}
LOCAL LSYSTIM get_ms(void)
{
	SYSTIM sys;
	tk_get_otm(&sys);
	return knl_toLSYSTIM(&sys);
}
LOCAL void update_missile(UB sw, UB x, UB y)
{
	pix_pln_clear(PLN_MISSILE);
	//新規作成
	if ( sw && (0==(g_cnt % 3)) ) {
		for (int i=0; i< MISS_NUM; i++) {
			if (TRUE == miss[i].exist) continue;
			miss[i].x = x + SHIP_WIDTH;
			miss[i].y = y + SHIP_HEIGHT-1;
			miss[i].exist = TRUE;
			break;
		}
	}
	for (int i=0; i<MISS_NUM; i++) {
		if (miss[i].exist == FALSE) continue;
		miss[i].x += 2; //move
		if (miss[i].x > 127) {
			memset(&miss[i], 0, sizeof(miss[i]));
			continue;
		}
		pix_line(PLN_MISSILE, miss[i].x, miss[i].y, miss[i].x-3, miss[i].y);
	}
}
LOCAL void update_alien(void)
{
	pix_pln_clear(PLN_ALIEN);
	//新規作成
	UW r = get_random();
	UW r2 = r >> 8;
	UW r3 = r2 >> 8;
	UW r4 = r3 >> 8;
	if (!(r % 100)) {
		for (int i=0; i< ALIEN_NUM; i++) {
			if (TRUE == ali[i].exist) continue;
			ali[i].cnt = (UB)(r % 256);
			ali[i].dir = r2 % 3;
			ali[i].x = OLE_W-ALIEN_SIZE + 2;//+2は初回表示値に２マイナスするため、あらかじめ追加
			ali[i].y = (UB)(r3 % KABE_TAKASA);
			ali[i].exist = TRUE;
			ali[i].bonus = (r4 % 10) ? FALSE: TRUE;
			break;
		}
	}
	for (int i=0; i<ALIEN_NUM; i++) {
		if (ali[i].exist == FALSE) continue;
		UB t;
		if (ali[i].bonus) {
			t = ((ali[i].cnt++) / 5) % 2; //bonus　は　表示パターン繰り返し頻度が高い
		} else {
			t = ((ali[i].cnt++) / 50) % 2;
		}
		//左端で削除
		if (ali[i].x < 2) {
			//delete alien
			memset(&ali[i], 0, sizeof(ali[i]));
			continue;
		}
		//方向転換
		if (ali[i].y < 1) {
			ali[i].dir = 2; //down
		} else if (ali[i].y > OLE_H-8) {
			ali[i].dir = 1; //up
		}
		ali[i].x -= 2;
		switch (ali[i].dir) {
		case 1:
			ali[i].y -= 1;
			break;
		case 2:
			ali[i].y += 1;
			break;
		}
		//書き出し
		pix_alien(t, ali[i].x, ali[i].y);
	}
}
LOCAL void app_init(ID* dd_adc)
{
	if (!(*dd_adc)) {
		ole_init();
		ole_set_area(0, 127, 0, 7);
		ole_clear(0x0);
		joy_init(dd_adc);
		sw_task_init();
	}
	g_cnt = 0;
	score = 0;
	pix_init();
	INIT_OBJ(ali);
	INIT_OBJ(miss);
	ship.x = (OLE_W >> 2);
	ship.y = (OLE_H >> 1);
}
LOCAL void update_ship(ID dd_adc, UB* target_x, UB* target_y)
{
	pix_pln_clear(PLN_SHIP);
	//ADC 第二引数：GP26=AD0=0, GP27=AD1=1, GP28=AD2=2
	UW ave[GP_SW_NUM];
	get_adc(dd_adc, ave);
	//進行方向への変換
	int x, y;
	js_vec(ave[0], &x);
	js_vec(ave[1], &y);
	//y *= -1;//極性反転
	//target境界条件チェック＆移動
	if ( !((*target_x<=1 && x < 0) || ((*target_x>=(OLE_W - SHIP_WIDTH - 2)) && x > 0)))	*target_x += x*2;
	if ( !((*target_y<1 && y < 0) || ((*target_y>=(OLE_H-2 - SHIP_HEIGHT-8)) && y > 0)))	*target_y += y;
	//絵描き
	ship_set(*target_x, *target_y);
}
LOCAL void task_disp(INT stacd, void *exinf)
{
	UB str[21];
	ID dd_adc = 0;

	app_init(&dd_adc);

	while(1)
	{
		tk_slp_tsk(TMO_FEVR);
		LSYSTIM bef = get_ms();
		stage = (g_cnt / STAGE_TICKS) % 2;
		//SW
		UB sw[GP_SW_NUM];
		db_get_val(sw);
		for (int i=0; i<GP_SW_NUM; i++) {
			sw[i] = sw[i] ? 0: 1;
		}
		if(sw[1]) { //pause
			tk_stp_cyc(CCYC2);
			tk_slp_tsk(WAIT_GAMEOVER);
			tk_sta_cyc(CCYC2);
		}
		//update
		update_kabe();
		update_ship(dd_adc, &ship.x, &ship.y);
		update_missile(sw[2], ship.x, ship.y);
		update_alien();
		//当たり判定
		miss_atari();
		BOOL b = atari(ship.x, ship.y);
		if (b) {
			memset(str, 0, sizeof(str));
			tm_sprintf(str, (UB*)"     GAME OVER");
			pix_prt(str, sizeof(str), GAME_OVER_LOC);
		}
		//top line
		memset(str, 0, sizeof(str));
		tm_sprintf(str, (UB*)"S:%07d", score + g_cnt/10);
		pix_prt(str, sizeof(str), 0);

		// ole out
		LSYSTIM b_flash = get_ms();
		pix_flash();
		LSYSTIM b_write = get_ms();
		pix_write();
		LSYSTIM aft = get_ms();

		if (b) {
			//一時停止
			tk_stp_cyc(CCYC2);
			tk_slp_tsk(WAIT_GAMEOVER);
			//再ゲーム開始
			app_init(&dd_adc);
			tk_sta_cyc(CCYC2);
		}
		g_cnt++;
		if (!(g_cnt % 100)) { // every 5 sec
			tm_printf((UB*)"working:%d / flash:%d / ole:%d\n", (int)(b_flash - bef),(int)(b_write - b_flash), (int)(aft - b_write));
		}
	}
	tk_ext_tsk();				// ここは実行されない
}

EXPORT INT usermain(void)
{
	static T_CTSK ctsk_disp = {
		.itskpri	= 10,			// 初期優先度
		.stksz		= 1024,			// スタックサイズ
		.task		= task_disp,		// 実行関数のポインタ
		.tskatr		= TA_HLNG | TA_RNG3,	// タスク属性
	};

	tm_printf((UB*)"User program started\n");

	tskid_disp = tk_cre_tsk(&ctsk_disp);	// タスクの生成
	tk_sta_tsk(tskid_disp, 0);		// タスクの実行

	tk_slp_tsk(TMO_FEVR);			//無限待ち

	return 0;				// ここは実行されない
}
