/*BMP280 barometric pressure and temperature sensor C Driver*/
/*Reza Ebrahimi - https://github.com/ebrezadev */
/*Version 1.0*/

#include <tk/tkernel.h>
#include <tk/device.h>		// デバイスドライバ定義ファイル
#include <bsp/libbsp.h>
#include <tm/tmonitor.h>

//#include "math.h"
#include "bmp280.h"

//extern float powf(float, float);
extern ID	dd_i2c;
/*writes an array (data[]) of arbitrary size (dataLength) to I2C address (deviceAddress), starting from an internal register address (startRegisterAddress)*/
void bmp280_write_array(uint8_t deviceAddress, uint8_t startRegisterAddress, uint8_t *data, uint8_t dataLength)
{
	SZ	asz;
	ER	err;

	int cnt = 0;
	uint8_t t_data[2*dataLength];
	if (dataLength>50) {
		tm_printf((UB*)"data length exceeds 50.\n");
		dataLength = 50;
	}
	for (int i=0; i<dataLength; i++) {
		t_data[cnt++] = startRegisterAddress++;
		t_data[cnt++] = data[i];
	}
	err = tk_swri_dev(dd_i2c, deviceAddress, t_data, dataLength*2, &asz);
}

/*reads an array (data[]) of arbitrary size (dataLength) from I2C address (deviceAddress), starting from an internal register address (startRegisterAddress)*/
void bmp280_read_array (uint8_t deviceAddress, uint8_t startRegisterAddress, uint8_t *data, uint8_t dataLength)
{
	T_I2C_EXEC exec;
	SZ	asz;
	ER	err;

	exec.sadr = deviceAddress;
	exec.snd_size = 1;
	exec.snd_data = &startRegisterAddress;
	exec.rcv_size = 1;
	exec.rcv_data = data;
	err = tk_swri_dev(dd_i2c, TDN_I2C_EXEC, &exec, sizeof(T_I2C_EXEC), &asz);
}

/*initiates the I2C peripheral and sets its speed*/
void bmp280_i2c_init()        
{
	if (dd_i2c == 0) {
		tm_printf((UB*)"dd_i2c may not initilized. init now.\n");
		dd_i2c = tk_opn_dev((UB*)"iica", TD_UPDATE);	// デバイスのオープン
	}
}

/*a delay function for milliseconds delay*/
void delay_function (uint32_t delayMS)
{
	tk_slp_tsk(delayMS);
}

/*implements a power function (used in altitude calculation)*/
float power_function (float x, float y)
{
	//return powf(x,y);//#include <math.h> has err
	return x;
}
