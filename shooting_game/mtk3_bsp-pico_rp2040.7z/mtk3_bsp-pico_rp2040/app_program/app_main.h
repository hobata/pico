/*
 * app_main.h
 *
 *  Created on: 2025/02/02
 *      Author: user
 */

#ifndef APP_PROGRAM_APP_MAIN_H_
#define APP_PROGRAM_APP_MAIN_H_

#define GP_SW_START		13
#define GP_SW_NUM		3

#define ADC_GP_NUM		2
#define ADV_AVE_NUM		3

#define STAGE_TICKS	300	// x 50ms

#define KABE_TAKASA ((OLE_H/8)*7) //KABEは、SRG1～7を使用
#define DOKU_H		10

#define SHIP_POLNUM	3
#define SHIP_WIDTH	10
#define SHIP_HEIGHT	7

#define ALIEN_HEIGHT	7
#define ALIEN_WIDTH	10
#define ALIEN_NUM	30

#define GAME_OVER_LOC	4		// row
#define WAIT_GAMEOVER	3000	// ms
#define MISS_LEN		3
#define MISS_NUM	30

typedef struct ship {
	UB x, y;
} ship_t;

typedef struct alien {
	UB x, y;
	BOOL exist;
	UB x_size, y_size;
	UB dir;//bit 0:up, bit 2:down
	UB cnt;
	BOOL bonus;
} alien_t;

typedef struct miss {
	UB x, y;
	BOOL exist;
} miss_t;

#endif /* APP_PROGRAM_APP_MAIN_H_ */
