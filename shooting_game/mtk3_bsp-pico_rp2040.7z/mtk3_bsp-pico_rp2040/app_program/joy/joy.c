/*
 * joy.c
 *
 *  Created on: 2025/02/08
 *      Author: user
 */

#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include "../app_main.h"
#include "joy.h"

extern void *memset(void *s, int c, size_t n);

void joy_init(ID *dd_adc)
{
	if (!(*dd_adc)) {
		*dd_adc = tk_opn_dev((UB*)"adca", TD_READ);
		if(*dd_adc < E_OK) {
			tm_printf((UB*)"Open Error %d\n", *dd_adc);
		}
	}
}
void get_adc(ID dd_adc, UW* ave)
{
	UB str[20];
	//ADC 第二引数：GP26=AD0=0, GP27=AD1=1, GP28=AD2=2,
	ER	err;
	UW	data_adc[ADC_GP_NUM];
	SZ	asz_adc;
	for (int i=0; i<ADC_GP_NUM; i++) {
		ave[i] = 0;
	}
	for (int j=0; j<ADV_AVE_NUM; j++) {
		for (int i=0; i<ADC_GP_NUM; i++) {
			err = tk_srea_dev(dd_adc, i, &data_adc[i], 1, &asz_adc);
			if(err < E_OK) {
				memset(str, 0, sizeof(str));
				tm_sprintf(str, (UB*)"ADC READ error %d", err);
				continue;
			}
			ave[i] += data_adc[i];
		}
	}
	for (int i=0; i<ADC_GP_NUM; i++) {
		ave[i] /= ADV_AVE_NUM;
	}
}
//joy stick の 方向検出
void js_vec(UW val, int* ret)
{
	int t = (val >> 9) - 4;
	switch( t ) {
	case -4:
	case -3:
		*ret = -1;
		break;
	case -2:
	case -1:
	case 0:
	case 1:
		*ret = 0;
		break;
	case 2:
	case 3:
	case 4:
		*ret = 1;
		break;
	default:
		tm_printf((UB*)"invalid vector value:%d\n", t);
		break;
	}
}

