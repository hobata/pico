/*
 * char.h
 *
 *  Created on: 2025/02/01
 *      Author: user
 */

#ifndef APP_PROGRAM_CHAR_CHAR_H_
#define APP_PROGRAM_CHAR_CHAR_H_

#include <tk/tkernel.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ALIEN_SIZE	10	// bytes per pattern
#define SHIP_SIZE	10
#define KABE_SIZE	8

extern const UB alien_font[];
extern const UB ship_font[];
extern const UB kabe_font[];

#endif /* APP_PROGRAM_CHAR_CHAR_H_ */
