/*
 * db.h
 *
 *  Created on: 2025/01/02
 *      Author: user
 */

#ifndef APP_PROGRAM_DB_H_
#define APP_PROGRAM_DB_H_

typedef struct {
	int integrator;
	int pre_output;
} CYC_T;

IMPORT void db_init(int first, int num);
IMPORT UW db_set_val(UW gpio, UW input);
IMPORT void db_get_val(UB* sw);

#endif /* APP_PROGRAM_DB_H_ */
