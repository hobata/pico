/******************************************************************************

debounce.c
written by Kenneth A. Kuhn
version 1.00

This is an algorithm that debounces or removes random or spurious
transistions of a digital signal read as an input by a computer.  This is
particularly applicable when the input is from a mechanical contact.  An

integrator is used to perform a time hysterisis so that the signal must
persistantly be in a logical state (0 or 1) in order for the output to change
to that state.  Random transitions of the input will not affect the output

except in the rare case where statistical clustering is longer than the
specified integration time.

The following example illustrates how this algorithm works.  The sequence
labeled, real signal, represents the real intended signal with no noise.  The

sequence labeled, corrupted, has significant random transitions added to the
real signal.  The sequence labled, integrator, represents the algorithm
integrator which is constrained to be between 0 and 3.  The sequence labeled,

output, only makes a transition when the integrator reaches either 0 or 3.
Note that the output signal lags the input signal by the integration time but
is free of spurious transitions.

real signal 0000111111110000000111111100000000011111111110000000000111111100000

corrupted   0100111011011001000011011010001001011100101111000100010111011100010
integrator  0100123233233212100012123232101001012321212333210100010123233321010
output      0000001111111111100000001111100000000111111111110000000001111111000

I have been using this algorithm for years and I show it here as a code
fragment in C.  The algorithm has been around for many years but does not seem
to be widely known.  Once in a rare while it is published in a tech note.  It

is notable that the algorithm uses integration as opposed to edge logic
(differentiation).  It is the integration that makes this algorithm so robust
in the presence of noise.
******************************************************************************/

#define DB_MAXIMUM         3 // at 10ms

/* These are the variables used */
#if 0
unsigned int input;       /* 0 or 1 depending on the input signal */
unsigned int integrator;  /* Will range from 0 to the specified MAXIMUM */
unsigned int output;      /* Cleaned-up version of the input signal */
#endif

/* Step 1: Update the integrator based on the input signal.  Note that the
integrator follows the input, decreasing or increasing towards the limits as
determined by the input state (0 or 1). */

#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include <bsp/libbsp.h>
#include "db.h"

#define BTN_NUM_MAX	3
LOCAL int g_first_gp;
LOCAL int g_sw_num;

ID	mtxid_db;
#define MTX_TO	50

/* default:1 = PULLUP */

//initial output is 1
LOCAL CYC_T g_cyc[BTN_NUM_MAX] = {
	{
			.integrator = DB_MAXIMUM,
			.pre_output = 1
	},
	{
			.integrator = DB_MAXIMUM,
			.pre_output = 1
	},
	{
			.integrator = DB_MAXIMUM,
			.pre_output = 1
	},
};
void db_init(int first, int num)
{
	//create mutex
	const T_CMTX db_m = {
			.mtxatr = TA_TFIFO,
	};
	mtxid_db = tk_cre_mtx(&db_m);

	tk_loc_mtx(mtxid_db, MTX_TO);
	{
		g_first_gp = first;
		if (num > BTN_NUM_MAX) {
			tm_printf((UB*)"exceed num:%d, max:%d\n", num, BTN_NUM_MAX);
			num = BTN_NUM_MAX;
		}
		g_sw_num =num;
	}
	tk_unl_mtx(mtxid_db);
}
UW db_set_val(UW gpio, UW input)
{
	int idx = gpio - g_first_gp;
	int ret = 0;
	CYC_T *t = &g_cyc[idx];

	tk_loc_mtx(mtxid_db, MTX_TO);
	{
		// Step 1
		if (input == 0) {
			if (t->integrator > 0) (t->integrator)--;
		} else if (t->integrator < DB_MAXIMUM) (t->integrator)++;

		/* Step 2: Update the output state based on the integrator.  Note that the
		output will only change states if the integrator has reached a limit,
		either 0 or MAXIMUM. */

		int output = 0;
	  if (t->integrator == 0) {
		  output = 0;
	  } else if (t->integrator >= DB_MAXIMUM) {
		  output = 1;
		  t->integrator = DB_MAXIMUM;  /* defensive code if integrator got corrupted */
	  }

	  //ボタン押し：1
	  if (t->pre_output==1 && output==0) {
		  ret = 1;
	  }
	  t->pre_output = output;

	}
	tk_unl_mtx(mtxid_db);
  return ret;
}
void db_get_val(UB* sw)
{
	tk_loc_mtx(mtxid_db, MTX_TO);
	{
		for (int i=0; i<g_sw_num; i++) {
			sw[i] = g_cyc[i].pre_output;
		}
	}
	tk_unl_mtx(mtxid_db);
}

/********************************************************* End of debounce.c */
