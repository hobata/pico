#ifndef _inc_font
#define _inc_font

#ifdef __cplusplus
extern "C" {
#endif

extern const UB font_prm[];
extern const UB font_8x5[];

#endif
