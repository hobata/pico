/*
 * ole.h
 *
 *  Created on: 2024/12/07
 *      Author: user
 */
#include "ssd1306_fonts.h"

#ifndef APP_PROGRAM_OLE_H_
#define APP_PROGRAM_OLE_H_

#define OLE_W	128
#define OLE_H	64
#define OLE_DN	(OLE_W*OLE_H/8)

/**
*	@brief defines commands used in ssd1306
*/
typedef enum {
    SET_CONTRAST = 0x81,
    SET_ENTIRE_ON = 0xA4,
    SET_NORM_INV = 0xA6,
    SET_DISP = 0xAE,
    SET_MEM_ADDR = 0x20,
    SET_COL_ADDR = 0x21,
    SET_PAGE_ADDR = 0x22,
    SET_DISP_START_LINE = 0x40,
    SET_SEG_REMAP = 0xA0,
    SET_MUX_RATIO = 0xA8,
    SET_COM_OUT_DIR = 0xC0,
    SET_DISP_OFFSET = 0xD3,
    SET_COM_PIN_CFG = 0xDA,
    SET_DISP_CLK_DIV = 0xD5,
    SET_PRECHARGE = 0xD9,
    SET_VCOM_DESEL = 0xDB,
    SET_CHARGE_PUMP = 0x8D
} ssd1306_command_t;

IMPORT ER ole_snd_cmd(UB* snd_data, UB len);
IMPORT void ole_init(void);
IMPORT ER ole_scroll_vh_r(BOOL right, UB spage, UB epage, UB step, UB offset);
IMPORT ER ole_scroll_h_r(BOOL right, UB spage, UB epage, UB step);
IMPORT void ole_clear(UB ptn);
IMPORT void ole_clear_size(UB ptn, UW len);
IMPORT void ole_set_area(UB x1, UB x2, UB y1, UB y2);
IMPORT void ole_prt(UB* c, UW len);
IMPORT void ole_set_data(UB* c, UW len);
IMPORT void ole_prt_t(font_type_t f_type, int x, int y, UB* c, UW len);
IMPORT void ole_set_marker(int x1, int x2, int y1, int y2);

#endif /* APP_PROGRAM_OLE_H_ */
