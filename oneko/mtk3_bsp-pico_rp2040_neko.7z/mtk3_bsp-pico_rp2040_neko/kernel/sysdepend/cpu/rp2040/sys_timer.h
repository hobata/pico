/*
 *----------------------------------------------------------------------
 *    micro T-Kernel 3.0 BSP
 *
 *    Copyright (C) 2021-2022 by Ken Sakamura.
 *    This software is distributed under the T-License 2.2.
 *----------------------------------------------------------------------
 *
 *    Released by TRON Forum(http://www.tron.org) at 2022/11.
 *
 *----------------------------------------------------------------------
 */

/*
 *	sys_timer.h (RP2040)
 *	Hardware-Dependent System Timer Processing
 */

#ifndef _SYSDEPEND_CPU_SYSTIMER_
#define _SYSDEPEND_CPU_SYSTIMER_

#include "../core/armv6m/sys_timer.h"

#endif /* _SYSDEPEND_CPU_SYSTIMER_ */