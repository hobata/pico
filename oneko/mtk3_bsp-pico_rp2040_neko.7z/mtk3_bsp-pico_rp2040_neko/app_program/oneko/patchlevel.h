#define PATCHLEVEL "1.2.sakura.5"
