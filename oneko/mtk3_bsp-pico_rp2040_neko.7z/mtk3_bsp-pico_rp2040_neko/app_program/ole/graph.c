/*
 * graph.c
 *
 *  Created on: 2024/12/07
 *      Author: user
 */
#include <tk/tkernel.h>
#include "ole.h"
#include "font.h"
#include "graph.h"
#include "../char/char.h"

void *memset(void *s, int c, size_t n);
int abs(int a);

#define rep(i, n) for (int i=0; i < (n); i++)
#define OLE_IDX(x, y)	((x)+(((y)/8)*OLE_W))

LOCAL UB g_write[PLN_NUM][OLE_DN];
LOCAL pln_t pln_i[PLN_NUM];

void pix_mask_kabe(UW cnt, UB x1, UB y1, UB y2)
{
	 // x2 is same as x1
	int cn = 0;
	if (y1 < y2) {
		for (int i=y1; i<=y2; i++) {
			if ( 0 == (kabe_font[cnt % KABE_SIZE] & (1<<(cn % 8))) ) {
				pix_clear(PLN_KABE, x1, i);
			}
			cn++;
		}
	} else {
		for (int i=y1; i>=y2; i--) {
			if ( 0 == (kabe_font[cnt % KABE_SIZE] & (1<<(cn % 8))) ) {
				pix_clear(PLN_KABE, x1, i);
			}
			cn++;
		}
	}
}
void pix_pln_clear(wPlane pln)
{
	memset(pln_i[pln].data, 0x0, OLE_DN);
}
void pix_pln_set(wPlane pln)
{
	memset(pln_i[pln].data, 0xff, OLE_DN);
}

LOCAL void pix_init_default(wPlane no)
{
	pln_t* p = &pln_i[no];
	p->segFrom = 0;		//全面を利用
	p->segTo = 7;
	p->data = g_write[(int)no];
	p->inv = FALSE;
	pix_pln_clear(no);
	if (no == PLN_MOUSE || no == PLN_TEXT) {
		p->inv = TRUE;
	}
	if (no == PLN_ALIEN) {
		p->inv = TRUE;
	}
	p->segNum = 1 + p->segTo - p->segFrom;
}
void pix_init(void)
{
	for (int i=0; i<PLN_NUM; i++) {
		pix_init_default(i);
	}
}

BOOL pix_exist(wPlane pln, UB x, UB y)
{
	return (pln_i[pln].data[OLE_IDX(x, y)] & (1<< (y % 8))) !=0 ? TRUE:FALSE;
}
#if 0
void pix_poligon(wPlane pln, UB x, UB y, UB* polxy, UB num, BOOL set)
{
	int loc = 0;
	int x1 = polxy[loc++];
	int y1 = polxy[loc++];
	int x2 = polxy[loc++];
	int y2 = polxy[loc++];
	for (int i=0; i<num; i++){
		if (set) {
			pix_line(pln, x1+x, y1+y, x2+x, y2+y);
		} else {
			pix_del_line(pln, x1+x, y1+y, x2+x, y2+y);
		}
		x1 = x2;
		y1 = y2;
		x2 = polxy[(loc++)%(num*2)];
		y2 = polxy[loc++];
	}
}
#endif
void pix_scroll_x(wPlane pln)
{
	//左方向 1dot のスクロール
	for (int y=0; y < OLE_H/8; y++) {
		for (int x=0; x < OLE_W; x++) {
			int loc = x + y * OLE_W;
			if (x < OLE_W-1) {
				pln_i[pln].data[loc] = pln_i[pln].data[loc+1];
			} else {
				pln_i[pln].data[loc] = 0;
			}
		}
	}
}
void pix_del_line(wPlane pln,int x0, int y0, int x1, int y1)
{
	   int dx = abs(x1-x0);
	   int dy = abs(y1-y0);
	   int sx, sy;
	   if (x0 < x1) { sx = 1; } else { sx = -1;}
	   if (y0 < y1) { sy = 1; } else { sy = -1;}
	   int err = dx-dy;

	   while(1) {
		 pix_clear(pln, x0, y0);
	     if (x0 == x1 && y0 == y1 ) break;
	     int e2 = 2*err;
	     if (e2 > -dy) {
	       err -= dy;
	       x0 += sx;
	     }
	     if (e2 <  dx) {
	       err += dx;
	       y0 += sy;
	     }
	   }
}
void pix_line(wPlane pln, int x0, int y0, int x1, int y1)
{
	   int dx = abs(x1-x0);
	   int dy = abs(y1-y0);
	   int sx, sy;
	   if (x0 < x1) { sx = 1; } else { sx = -1;}
	   if (y0 < y1) { sy = 1; } else { sy = -1;}
	   int err = dx-dy;

	   while(1) {
		 pix_set(pln, x0, y0);
	     if (x0 == x1 && y0 == y1 ) break;
	     int e2 = 2*err;
	     if (e2 > -dy) {
	       err -= dy;
	       x0 += sx;
	     }
	     if (e2 <  dx) {
	       err += dx;
	       y0 += sy;
	     }
	   }
}
void pix_prt(UB* c, UW len, UB y)
{
	UB* d_data = pln_i[PLN_TEXT].data;
	memset(d_data + y*(OLE_DN/8), 0x0, OLE_DN/8);
    int cnt = 1 + OLE_DN/8*y; // column from 1 to 126 (126 % 6 = 0)
    for (int k=0; k < len; k++) {
       int col = c[k] - font_prm[3];
       if (col < 0) col = 0;
       for (int j=0; j<5; j++){
    	   d_data[cnt++] = font_8x5[col*5+j];
       }
	   d_data[cnt++] = 0x0; //6列目 文字の間
    }
}
void pix_alien(UB type, UB x, UB y)
{
	for (int k=0; k < ALIEN_SIZE; k++) {
		UB val = alien_font[type*ALIEN_SIZE+k];
		for (int i=0; i < 8; i++) {
			if (val & (1 << i)) {
				pix_set(PLN_ALIEN, x+k, y+i);
			}
		}
	}
}
void pix_ship(UB type, UB x, UB y)
{
	for (int k=0; k < SHIP_SIZE; k++) {
		UB val = ship_font[type*SHIP_SIZE+k];
		for (int i=0; i < 8; i++) {
			if (val & (1 << i)) {
				pix_set(PLN_SHIP, x+k, y+i);
			}
		}
	}
}
void pix_text_size(unsigned char* p, UB x, UB y, UB sx, UB sy)
{
	for (int m=0; m < sy/8; m++) {
		for (int k=0; k < sx; k++) {
			UB val = p[k + m*sx];
			for (int i=0; i < 8; i++) {
				if (val & (1 << i)) {
					pix_set(PLN_TEXT, x+k, y+i+m*8);
				}
			}
		}
	}
}
void pix_mouse_size(unsigned char* p, UB x, UB y, UB sx, UB sy)
{
	for (int m=0; m < sy/8; m++) {
		for (int k=0; k < sx; k++) {
			UB val = p[k + m*sx];
			for (int i=0; i < 8; i++) {
				if (val & (1 << i)) {
					pix_set(PLN_MOUSE, x+k, y+i+m*8);
				}
			}
		}
	}
}
void pix_flash(void)
{
	ole_set_area(0, OLE_W-1, 0, OLE_H/8-1);
	//pix_pln_clear(PLN_TARGET);
	pix_pln_set(PLN_TARGET);
	for (int j=1; j < PLN_NUM; j++) {
		for (int i = 0; i < (OLE_DN/8)*pln_i[j].segNum; i++) {
			if (pln_i[j].inv) {
				pln_i[PLN_TARGET].data[i+(OLE_DN/8)*pln_i[j].segFrom] ^= pln_i[j].data[i];
			} else {
				pln_i[PLN_TARGET].data[i+(OLE_DN/8)*pln_i[j].segFrom] |= pln_i[j].data[i];
			}
		}
	}
	//ole_set_data(pln_i[PLN_TARGET].data, OLE_DN);
}
void pix_inv(void)
{
	for (int i = 0; i < OLE_DN; i++) {
		pln_i[PLN_TARGET].data[i] = !pln_i[PLN_TARGET].data[i];
	}
}
void pix_write(void)
{
	ole_set_data(pln_i[PLN_TARGET].data, OLE_DN);
}
void pix_clear(wPlane pln, UB x, UB y)
{
	UB *p = &(pln_i[pln].data[OLE_IDX(x, y)]); //(y/8)*OLE_W+x
	*p &= ~(1 << (y % 8));
}
void pix_set(wPlane pln, int x, int y)
{
	UB *p = &(pln_i[pln].data[OLE_IDX(x, y)]); //(y/8)*OLE_W+x
	*p |= 1 << (y % 8);
}
