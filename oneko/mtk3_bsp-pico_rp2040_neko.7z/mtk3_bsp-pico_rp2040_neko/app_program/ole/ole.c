/*
 * ole.c
 * SSD1306 driver
 *
 *  Created on: 2024/12/07
 *      Author: user
 */
#include <tk/tkernel.h>
#include <tk/device.h>		// デバイスドライバ定義ファイル
#include <bsp/libbsp.h>
#include <stdint.h>
#include "ole.h"

#include "font.h"
#include "ssd1306_fonts.h"

#define S_ADR	0x3c	// ① I/OデバイスのI2Cアドレス定義
#define CNTLB 0x80 // continuous bit
#define D_DATA   0x40  // DATA bit
void *memset(void *s, int c, size_t n);

ID	dd_i2c;
static ER	err;
static SZ	asz;

ER ole_snd_cmd(UB* snd_data, UB len)
{
	UB w_data[100];
    int cnt = 0;
	for (int i=0; i < len; i++){
    	w_data[cnt++] = CNTLB;
    	w_data[cnt++] = snd_data[i];
    }
	return tk_swri_dev(dd_i2c, S_ADR, w_data, cnt, &asz);
}
void ole_init(void)
{
	//HW　I2C0 GP8, GP9 kernel/sysdepend/pico_rp2040/hw_setting.h を参照
	dd_i2c = tk_opn_dev((UB*)"iica", TD_UPDATE);		// デバイスのオープン
	tk_slp_tsk(1); // これが無い場合：「開発環境からは正常起動するが、USB接続のみ時はI2CでSlaveからNACKが帰る」。

	UB	height=64, width = 128;
	//初期化 data sheet Figure 2 : Software Initialization Flow Chart
	//https://analogicintelligence.blogspot.com/2019/03/mycropythonoled.html
	//https://analogicintelligence.blogspot.com/2019/04/mycropythonoled.html
	UB	snd_data[] = { // 初期化送信データ
	        SET_DISP, // set  display off
	        // timing and driving scheme
	        SET_DISP_CLK_DIV,
	        0x80, // reset
	        SET_MUX_RATIO,
	        height - 1, // COM0 to 63
	        SET_DISP_OFFSET,
	        0x00, //mapping of the display start line to one of COM0~COM63
	        // resolution and layout
	        SET_DISP_START_LINE, //start line is COM0
	        // charge pump
	        SET_CHARGE_PUMP, // 0x14で有効(必須)
	        0 ? 0x10:0x14,					//external vcc
	        SET_SEG_REMAP | 0x1,        // column addr 127 mapped to SEG0
			SET_COM_OUT_DIR | 0x8,			// remapped mode. Scan from	COM[N-1] to COM0
	        SET_COM_PIN_CFG,
	        width>2*height?0x02:0x12,
	        // display
	        SET_CONTRAST,
	        0x7f,
			SET_PRECHARGE,
	        0 ? 0x22:0xF1,					//external vcc
	        SET_VCOM_DESEL,
	        0x40,                           //0x30 or 0x40?
			SET_ENTIRE_ON,                  // output follows RAM contents
	        SET_NORM_INV,                   // set normal display not inverted
			SET_DISP | 0x01, // display on
	        // address setting
			SET_MEM_ADDR,
	        0x00,  // horizontal
	};
	ole_snd_cmd(snd_data, sizeof(snd_data));
}
ER ole_scroll_vh_r(BOOL right, UB spage, UB epage, UB step, UB offset)
{
	UB cmd[] ={
			0x2e, //deactivate scrolling
			right ? 0x29:0x2a,
			0x0, //dummy
			spage,
			step,
			epage,
			offset,
			0x2f // activate scrolling
	};
	return ole_snd_cmd(cmd, sizeof(cmd));
}
ER ole_scroll_h_r(BOOL right, UB spage, UB epage, UB step)
{
	UB cmd[] ={
			0x2e, //deactivate scrolling
			right ? 0x26:0x27,
			0x0, //dummy
			spage,
			step,
			epage,
			0x00,
			0xff,
			0x2f // activate scrolling
	};
	return ole_snd_cmd(cmd, sizeof(cmd));
}
void ole_clear(UB ptn)
{
	tk_slp_tsk(1); // ゴミが入る場合があるので待ちを入れる。
	//画面 data
	UB d_data[64+1];//display data　フルサイズ：128*8まで繰り返し
    memset(d_data, ptn, sizeof(d_data));
    d_data[0] = D_DATA;
    for (int i=0; i<16; i++) {
    	err = tk_swri_dev(dd_i2c, S_ADR, d_data, sizeof(d_data), &asz);
    }
}
void ole_clear_size(UB ptn, UW len)
{
	tk_slp_tsk(1); // ゴミが入る場合があるので待ちを入れる。
	//画面 data
	UB d_data[64+1];//display data　フルサイズ：128*8まで繰り返し
    memset(d_data, ptn, sizeof(d_data));
    d_data[0] = D_DATA;
    UW remain = 128*16 - len;
    while(remain > 0) {
    	int snd_len = (remain >= 64) ? 64: remain % 64;
    	err = tk_swri_dev(dd_i2c, S_ADR, d_data, snd_len + 1, &asz);
    	remain -= snd_len;
    }
}
void ole_set_area(UB x1, UB x2, UB y1, UB y2)
{
    //area setting
    UB area[] = {
    	    SET_COL_ADDR,
			x1,
			x2,
    	    SET_PAGE_ADDR,
			y1,
			y2
    };
	ole_snd_cmd(area, sizeof(area));
}
void ole_prt(UB* c, UW len)
{
	static UB d_data[96+1]; // less than 100(DEVCNF_I2C_MAX_SDATSZ)
    for (int k=0; k < len /16 +1; k++) {
       memset(d_data, 0x00, sizeof(d_data));
       int cnt = 0;
       d_data[cnt++] = 0x40;
    	for (int i=0; i < 16; i++){
    		if (k*16+i > len - 1) break;
    		if (NULL == c[i+k*16]) break;//end of line
    		int col = c[i+k*16] - font_prm[3];
    		if (col < 0) col = 0;
    		for (int j=0; j<5; j++){
    			d_data[cnt++] = font_8x5[col*5+j];
    		}
    		d_data[cnt++] = 0x0; //6列目 文字の間
    	}
    	err = tk_swri_dev(dd_i2c, S_ADR, d_data, cnt, &asz);
    }
}
#define I2C_LEN	(100-1)
void ole_set_data(UB* c, UW len)
{
	static UB d_data[I2C_LEN]; // less than 100(DEVCNF_I2C_MAX_SDATSZ)
    d_data[0] = 0x40;

    for (int i=0; i < len; i+=I2C_LEN) {
    	int n = (i + I2C_LEN <= len) ? I2C_LEN : len - i;
    	int cnt;
    	for (cnt=1; cnt <= n; cnt++) {
    		d_data[cnt] = *c;
    		c++;
    	}
        err = tk_swri_dev(dd_i2c, S_ADR, d_data, cnt, &asz);
    }
}
const UB* fntType[] = {
		free_calibri11x12,
		free_calibri11x12_cyrillic,
		free_calibri11x12_latin,
		ssd1306xled_font8x16,
		courier_new_font11x16_digits,
		comic_sans_font24x32_123,

		ssd1306xled_font6x8,
		ssd1306xled_font6x8_German,
		ssd1306xled_font6x8_AB,
		ssd1306xled_font5x7,
		ssd1306xled_font5x7_AB,
		digital_font5x7_123,
		digital_font5x7_AB,
		digital_font5x7,
};
void ole_prt_t(font_type_t f_type, int x, int y, UB* c, UW len)
{
	const UB* pfnt = fntType[f_type];

	int xpix = pfnt[1];
	int ypix = pfnt[2];
	const int d_oft = 4; //data offset

	UB data[100];
	int ys;
	if (ypix <= 8) {
		ys = 1;
	} else if (ypix <= 16) {
		ys = 2;
	} else if (ypix <= 32) {
		ys = 4;
	}
	int c_mul = xpix*ys;
	for (int j=0; j < len; j++) { //１文字
		int cnt = 0;
		data[cnt++] = 0x40;//DATA
		if (c[j] < ' ') {
			break;//文字列の終了
		}
		int c_oft = c[j] - ' ';
		int x_loc = x+j*(xpix+1);
		ole_set_area(x_loc, x_loc + xpix, y, y + ys - 1);//１文字出力の領域
		for (int yy=0; yy < ys; yy++) {
			for (int xx=0; xx < xpix; xx++) {
				data[cnt++] = pfnt[d_oft + c_oft*c_mul + xx+yy*xpix];
			}
			data[cnt++] = 0x0; //文字の一番右側、文字間に相当
		}
		if (cnt > 100) cnt = 100;
    	err = tk_swri_dev(dd_i2c, S_ADR, data, cnt, &asz);
	}
}
void ole_set_marker(int x1, int x2, int y1, int y2)
{
	static BOOL ptn = TRUE;
	ole_set_area(x1, x2, y1, y2);
	ole_clear_size(ptn, (x2-x1+1)*(y2-y1+1));
	ptn = !ptn;
}

