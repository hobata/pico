/*
 * graph.h
 *
 *  Created on: 2024/12/07
 *      Author: user
 */

#ifndef APP_PROGRAM_GRAPH_H_
#define APP_PROGRAM_GRAPH_H_

typedef enum {
	PLN_TARGET = 0,
	PLN_TEXT,
	PLN_MOUSE,
	PLN_NUM,
	PLN_KABE,
	PLN_ALIEN,
	PLN_SHIP,
	PLN_MISSILE,
} wPlane;

typedef struct pln_st {
	UB segFrom;
	UB segTo;
	UB segNum;
	B  inv;
	UB *data;
} pln_t;

void pix_init(void);
void pix_prt(UB* c, UW len, UB y);
void pix_flash(void);
void pix_write(void);
void pix_set(wPlane, int x, int y);
void pix_clear(wPlane, UB x, UB y);
void pix_line(wPlane, int x0, int y0, int x1, int y1);
void pix_del_line(wPlane, int x0, int y0, int x1, int y1);
void pix_scroll_x(wPlane);
BOOL pix_exist(wPlane, UB x, UB y);
//void pix_poligon(wPlane pln, UB x, UB y, UB* polxy, UB num, BOOL set);
void pix_alien(UB type, UB x, UB y);
void pix_ship(UB type, UB x, UB y);
void pix_pln_clear(wPlane pln);
void pix_pln_set(wPlane pln);
void pix_mask_kabe(UW cnt, UB x1, UB y1, UB y2);
void pix_text_size(unsigned char* ch, UB x, UB y, UB sx, UB sy);
void pix_mouse_size(unsigned char* ch, UB x, UB y, UB sx, UB sy);
void pix_inv(void);

#endif /* APP_PROGRAM_GRAPH_H_ */
