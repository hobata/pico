/*
 *----------------------------------------------------------------------
 *    micro T-Kernel 3.0 BSP
 *
 *    Copyright (C) 2022-2023 by Ken Sakamura.
 *    This software is distributed under the T-License 2.2.
 *----------------------------------------------------------------------
 *
 *    Released by TRON Forum(http://www.tron.org) at 2023/05.
 *
 *----------------------------------------------------------------------
 */

/*
 *	app_main.c
 *	Application main program for RaspberryPi Pico
 */

#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include <bsp/libbsp.h>
#include <sys/queue.h>
#include <../kernel/tkernel/timer.h>

#include "ole/ole.h"
#include "ole/graph.h"
#include "gpio/address_mapped.h"
#include "debounce/db.h"
#include "app_main.h"
#include "oneko/oneko.h"

#define INIT_OBJ(a)		memset((a), 0x0, sizeof((a)))

//猫の状態ごとのアニメーションパターン
UB anime[] = {
		0,0, 1,0, 2,3, 4,4, 5,6, 7,7, 8,9, 10,11,
		12,13, 14,15, 16,17, 18,19, 20,21, 22,23, 24,25, 26,27,
		28,29, 30,31,
};
//起動時選択したキャラクタ
unsigned char* ch_ptn[] = {
		neko,
		tora,
		dog,
		bsd,
		sakura,
		tomoyo,
};
//switchの状態 NEKO_MS当たりの管理
UB sws[GP_SW_NUM];

extern void *memset(void *s, int c, size_t n);

LOCAL void task_disp(INT stacd, void *exinf);	// 実行関数
LOCAL ID	tskid_disp;			// ID番号
LOCAL ID CCYC1; //SWの検出cycle
LOCAL ID CCYC2; //INT_MSのcycle

ne_obj_t ne_obj; //nekoオブジェクト

int		WindowWidth	= OLE_W;
int		WindowHeight = OLE_H;

const double  SinPiPer8Times3 = 0.92387953253251129;        /* sin(３π／８) */
const double  SinPiPer8 = 0.38268343236509;              /* sin(π／８) */

LOCAL LSYSTIM get_ms(void)
{
	SYSTIM sys;
	tk_get_otm(&sys);
	return knl_toLSYSTIM(&sys);
}
LOCAL UW get_random(void)
{
	UW val = 0;
	for (int i=0; i<32; i++) {
	  val |= (*(io_rw_32 *)(ROSC_BASE | 0x1c)) & 1;
	  val <<= 1;
	}
	return val;
}
LOCAL float sqrt(float number)
{	//https://qiita.com/metaphysical_bard/items/e04378b16d6173127435
  long i;
  float x2, y;
  const float threehalfs = 1.5F;

  x2 = number * 0.5F;
  y  = number;
  i  = * ( long * ) &y;                       // evil floating point bit level hacking
  i  = 0x5f3759df - ( i >> 1 );               // what the fuck?
  y  = * ( float * ) &i;
  y  = y * ( threehalfs - ( x2 * y * y ) );   // 1st iteration
  // y  = y * ( threehalfs - ( x2 * y * y ) );   // 2nd iteration, this can be removed

  float ret = y*number;
  if (ret < 0) ret = 0;
  return ret;
}
LOCAL void SetNekoState(int SetValue, ne_obj_t* p)
{
    p->NekoTickCount = 0;
    p->NekoStateCount = 0;

    p->NekoState = SetValue;
}
/*
 *      猫移動方法決定
 *
 *      This sets the direction that the neko is moving.
 *
 */
LOCAL void NekoDirection(ne_obj_t* p)
{
    int                 NewState;
    double              LargeX, LargeY;
    double              Length;
    double              SinTheta;

    if (p->NekoMoveDx == 0 && p->NekoMoveDy == 0) {
        NewState = NEKO_STOP;
    } else {
        LargeX = (double)p->NekoMoveDx;
        LargeY = (double)(-1*p->NekoMoveDy);
        Length = (double)sqrt(LargeX * LargeX + LargeY * LargeY);
    	//tm_printf((UB*)"x,y,len:%d,%d, %d\n", LargeX, LargeY, (int)Length);
        SinTheta = LargeY / Length;

        if (p->NekoMoveDx > 0) {
            if (SinTheta > SinPiPer8Times3) {
                NewState = NEKO_U_MOVE;
            } else if ((SinTheta <= SinPiPer8Times3)
                        && (SinTheta > SinPiPer8)) {
                NewState = NEKO_UR_MOVE;
            } else if ((SinTheta <= SinPiPer8)
                        && (SinTheta > -(SinPiPer8))) {
                NewState = NEKO_R_MOVE;
            } else if ((SinTheta <= -(SinPiPer8))
                        && (SinTheta > -(SinPiPer8Times3))) {
                NewState = NEKO_DR_MOVE;
            } else {
                NewState = NEKO_D_MOVE;
            }
        } else {
            if (SinTheta > SinPiPer8Times3) {
                NewState = NEKO_U_MOVE;
            } else if ((SinTheta <= SinPiPer8Times3)
                        && (SinTheta > SinPiPer8)) {
                NewState = NEKO_UL_MOVE;
            } else if ((SinTheta <= SinPiPer8)
                        && (SinTheta > -(SinPiPer8))) {
                NewState = NEKO_L_MOVE;
            } else if ((SinTheta <= -(SinPiPer8))
                        && (SinTheta > -(SinPiPer8Times3))) {
                NewState = NEKO_DL_MOVE;
            } else {
                NewState = NEKO_D_MOVE;
            }
        }
    }

    if (p->NekoState != NewState) {
        SetNekoState(NewState, p);
    }
}
LOCAL void CalcDxDy(ne_obj_t* p)
{
    double          LargeX, LargeY;
    double          DoubleLength, Length;
	//dummy value
    double			NekoSpeed = 10;

    p->PrevMouseX = p->MouseX;
    p->PrevMouseY = p->MouseY;
    LargeX = (double)(p->MouseX - p->NekoX - BITMAP_WIDTH / 2);
    LargeY = (double)(p->MouseY - p->NekoY - BITMAP_HEIGHT / 2);

    DoubleLength = LargeX * LargeX + LargeY * LargeY;

    if (DoubleLength != (double)0) {
        Length = sqrt(DoubleLength);
        if (Length <= NekoSpeed) {
            p->NekoMoveDx = (int)LargeX;
            p->NekoMoveDy = (int)LargeY;
        } else {
            p->NekoMoveDx = (int)((NekoSpeed * LargeX) / Length);
            p->NekoMoveDy = (int)((NekoSpeed * LargeY) / Length);
        }
    } else {
        p->NekoMoveDx = p->NekoMoveDy = 0;
    }
	//tm_printf((UB*)"CalcDxDy:%d,%d\n", NekoMoveDx, NekoMoveDy);
}

LOCAL void DrawNeko(int x, int y, unsigned char* p)
{
	pix_pln_clear(PLN_TEXT);
	pix_prt((UB*)"oneko", 5, 0);
	pix_text_size(p, (UB)x, (UB)y, BITMAP_WIDTH, BITMAP_HEIGHT);
}

LOCAL void DrawMouse(unsigned char* p, ne_obj_t* q)
{
	pix_pln_clear(PLN_MOUSE);
	//猫と重なっている場合は、マウスを描画しない、
	if ( (q->MouseX > q->NekoX && q->MouseX < q->NekoX+BITMAP_WIDTH)
			&& (q->MouseY > q->NekoY && q->MouseY < q->NekoY+BITMAP_HEIGHT) ) {
		return;
	}
	pix_mouse_size(p, q->MouseX, q->MouseY, mouse_cursor_width, mouse_cursor_height);
}
LOCAL B IsWindowOver(ne_obj_t* p)
{
    B	ReturnValue = FALSE;

    if (p->NekoY <= 0) {
        p->NekoY = 0;
        ReturnValue = TRUE;
    } else if (p->NekoY >= WindowHeight - BITMAP_HEIGHT) {
        p->NekoY = WindowHeight - BITMAP_HEIGHT;
        ReturnValue = TRUE;
    }
    if (p->NekoX <= 0) {
        p->NekoX = 0;
        ReturnValue = TRUE;
    } else if (p->NekoX >= WindowWidth - BITMAP_WIDTH) {
        p->NekoX = WindowWidth - BITMAP_WIDTH;
        ReturnValue = TRUE;
    }
	//tm_printf((UB*)"IsWindowOver Neko:%d,%d, ret:%d\n", NekoX, NekoY, ReturnValue);
    return(ReturnValue);
}

LOCAL B IsNekoDontMove(ne_obj_t* p)
{
//	tm_printf((UB*)"IsNekoDontMove Neko:%d,%d, Last:%d,%d\n", NekoX, NekoY, NekoLastX, NekoLastY);
    if (p->NekoX == p->NekoLastX && p->NekoY == p->NekoLastY) {
        return(TRUE);
    } else {
        return(FALSE);
    }
}

/*
 *      猫移動開始判定
 */
LOCAL B IsNekoMoveStart(ne_obj_t* p)
{
	if ((p->PrevMouseX >= p->MouseX - p->IdleSpace
         && p->PrevMouseX <= p->MouseX + p->IdleSpace) &&
         (p->PrevMouseY >= p->MouseY - p->IdleSpace
         && p->PrevMouseY <= p->MouseY + p->IdleSpace)) {
//		tm_printf((UB*)"IsNekoMoveStart:FALSE\n");
        return(FALSE);
    } else {
//		tm_printf((UB*)"IsNekoMoveStart:TRUE\n");
        return(TRUE);
    }
}
LOCAL void TickCount(ne_obj_t* p)
{
    if (++(p->NekoTickCount) >= MAX_TICK) {
        p->NekoTickCount = 0;
    }

    if (p->NekoTickCount % 2 == 0) {
        if (p->NekoStateCount < MAX_TICK) {
            p->NekoStateCount++;
        }
    }
}

LOCAL void get_new_mouse(int* x, int* y)
{
	*x = (int)(get_random() % OLE_W);
	*y = (int)(get_random() % OLE_H);
	//tm_printf((UB*)"New:%d,%d\n", *x, *y);
}
LOCAL void NekoThinkDraw(ne_obj_t* p)
{
	CalcDxDy(p); //neko 移動量計算

	//マウスを描画
	DrawMouse(&mouse_bitmap[0], p);
    int idx;
    if (p->NekoState != NEKO_SLEEP) {
    	idx = anime[p->NekoState*2 + (p->NekoTickCount & 0x1)];
	} else {
    	idx = anime[p->NekoState*2 + ((p->NekoTickCount >> 2) & 0x1)];
    }
	//tm_printf((UB*)"Sta:%d, idx:%d\n", NekoState, idx);
    //nekoを描画
    DrawNeko(p->NekoX, p->NekoY, &p->data[idx*CH_SIZE]);

    p->NekoLastX = p->NekoX; // neko 現在位置の退避
    p->NekoLastY = p->NekoY;

	//SW : update mouse
#if 1
	if (sws[0]) {
		//mouseの位置更新
		get_new_mouse(&(p->MouseX), &(p->MouseY));
	}
#else　// debug
	if (sws[0]) {
		MouseX-=10;
	}
	if (sws[1]) {
		MouseX+=10;
	}
	if (sws[2]) {
		MouseY-=5;
	}
	if (sws[3]) {
		MouseY+=5;
	}
	if (sws[0] || sws[1] || sws[2] || sws[3]) {
		tm_printf((UB*)"sw:%d,%d,%d,%d\n", sw[0],sw[1],sw[2],sw[3]);
	}
#endif
	INIT_OBJ(sws);//mouse位置更新したので、swsの値をクリアする

	TickCount(p);

	//方向計算および、neko位置の更新(移動量を加算)
    switch (p->NekoState) {
    case NEKO_STOP:
        if (IsNekoMoveStart(p)) {
            SetNekoState(NEKO_AWAKE, p);
            break;
        }
        if (p->NekoStateCount < NEKO_STOP_TIME) {
            break;
        }
        if (p->NekoMoveDx < 0 && p->NekoX <= 0) {
            SetNekoState(NEKO_L_TOGI, p);
        } else if (p->NekoMoveDx > 0 && p->NekoX >= WindowWidth - BITMAP_WIDTH) {
            SetNekoState(NEKO_R_TOGI, p);
        } else if (p->NekoMoveDy < 0 && p->NekoY <= 0){
            SetNekoState(NEKO_U_TOGI, p);
        } else if ((p->NekoMoveDy > 0 && p->NekoY >= WindowHeight - BITMAP_HEIGHT)
                       &&  p->NekoY < p->MouseY - BITMAP_HEIGHT){
            SetNekoState(NEKO_D_TOGI, p);
        } else {
            SetNekoState(NEKO_JARE, p);
        }
        break;
    case NEKO_JARE:
        if (IsNekoMoveStart(p)) {
            SetNekoState(NEKO_AWAKE, p);
            break;
        }
        if (p->NekoStateCount < NEKO_JARE_TIME) {
            break;
        }
        SetNekoState(NEKO_KAKI, p);
        break;
    case NEKO_KAKI:
        if (IsNekoMoveStart(p)) {
            SetNekoState(NEKO_AWAKE, p);
            break;
        }
        if (p->NekoStateCount < NEKO_KAKI_TIME) {
            break;
        }
        SetNekoState(NEKO_AKUBI, p);
        break;
    case NEKO_AKUBI:
        if (IsNekoMoveStart(p)) {
            SetNekoState(NEKO_AWAKE, p);
            break;
        }
        if (p->NekoStateCount < NEKO_AKUBI_TIME) {
            break;
        }
        SetNekoState(NEKO_SLEEP, p);
        break;
    case NEKO_SLEEP:
        if (IsNekoMoveStart(p)) {
            SetNekoState(NEKO_AWAKE, p);
            break;
        }
        break;
    case NEKO_AWAKE:
        if (p->NekoStateCount < NEKO_AWAKE_TIME) {
            break;
        }
        NekoDirection(p);        /* 猫が動く向きを求める */
        break;
    case NEKO_U_MOVE:
    case NEKO_D_MOVE:
    case NEKO_L_MOVE:
    case NEKO_R_MOVE:
    case NEKO_UL_MOVE:
    case NEKO_UR_MOVE:
    case NEKO_DL_MOVE:
    case NEKO_DR_MOVE:
        p->NekoX += p->NekoMoveDx;
        p->NekoY += p->NekoMoveDy;
        NekoDirection(p);
        if (IsWindowOver(p)) {
            if (IsNekoDontMove(p)) {
                SetNekoState(NEKO_STOP, p);
            }
        }
        break;
    case NEKO_U_TOGI:
    case NEKO_D_TOGI:
    case NEKO_L_TOGI:
    case NEKO_R_TOGI:
        if (IsNekoMoveStart(p)) {
            SetNekoState(NEKO_AWAKE, p);
            break;
        }
        if (p->NekoStateCount < NEKO_TOGI_TIME) {
            break;
        }
        SetNekoState(NEKO_KAKI, p);
        break;
    default:
        /* Internal Error */
        SetNekoState(NEKO_STOP, p);
        break;
    }
}

LOCAL void cyc_cb(void *exinf)
{
	//SWの値をdebounceで処理するのみ。
	for (int i=GP_SW_START; i < GP_SW_START+GP_SW_NUM; i++) {
		db_set_val(i, gpio_get_val(i));
	}
}
LOCAL void cyc_cb2(void *exinf)
{
	tk_wup_tsk(tskid_disp); //タスク起床
}
LOCAL void sw_task_init(void)
{
	static T_CCYC ccyc = {	// check input / 10 msec
			.exinf = NULL,		/* Extended information */
			.cycatr = TA_STA,	/* Cycle handler attribute */
			.cychdr = cyc_cb,	/* Cycle handler address */
			.cyctim = SW_INT,		/* Cycle interval */
			.cycphs = SW_INT,		/* Cycle phase */
	};

	//GPIO IN設定 SIOはset_wは効果なし
	/* The SIO (Section 2.3.1), a single-cycle IO block attached directly
	to the cores' IO ports, does not support atomic accesses at the bus level,
	although some individual registers (e.g. GPIO) have set/clear/xor aliases.
	*/
	for (int i=GP_SW_START; i<GP_SW_START+GP_SW_NUM; i++) {
		gpio_set_pin(i, GPIO_MODE_IN);
		//pull up
		out_w(GPIO(i), GPIO_OD | GPIO_IE | GPIO_DRIVE_4MA | GPIO_PUE | GPIO_SHEMITT);
	}
	//debounce
	db_init(GP_SW_START, GP_SW_NUM);
	CCYC1 = tk_cre_cyc(&ccyc);

	//get val
	static T_CCYC ccyc2 = {	// get value / 100 msec
			.exinf = NULL,		/* Extended information */
			.cycatr = TA_STA,	/* Cycle handler attribute */
			.cychdr = cyc_cb2,	/* Cycle handler address */
			.cyctim = INT_MS,		/* Cycle interval */
			.cycphs = INT_MS,		/* Cycle phase */
	};
	CCYC2 = tk_cre_cyc(&ccyc2);
}

LOCAL void anime_init(ne_obj_t* p, UB idx)
{
	ole_clear(0xff);
	pix_init();
	p->NekoState = NEKO_STOP;
	p->NekoTickCount = 0;          /* 猫動作カウンタ */
	p->NekoStateCount = 0;         /* 猫同一状態カウンタ */
	p->NekoMoveDx = 0;             /* 猫移動距離Ｘ */
	p->NekoMoveDy = 0;             /* 猫移動距離Ｙ */
	p->IdleSpace = 2;                  /*   idle       */
#if 1
	p->NekoX = get_random() % (OLE_W-BITMAP_WIDTH);		/* 猫Ｘ座標 */
	p->NekoY = get_random() % (OLE_H-BITMAP_HEIGHT);		/* 猫Ｙ座標 */
#else
	p->NekoX = OLE_W/2-BITMAP_WIDTH/2;		/* 猫Ｘ座標 */
	p->NekoY = OLE_H/2-BITMAP_HEIGHT/2;		/* 猫Ｙ座標 */
#endif
	p->NekoLastX = p->NekoX;              /* 猫最終描画Ｘ座標 */
	p->NekoLastY = p->NekoY;              /* 猫最終描画Ｙ座標 */

	p->MouseX = p->NekoX + BITMAP_WIDTH/2;                 /* マウスＸ座標 */
	p->MouseY = p->NekoY + BITMAP_HEIGHT/2;                 /* マウスＹ座標 */
	p->PrevMouseX = p->MouseX;         /* 直前のマウスＸ座標 */
	p->PrevMouseY = p->MouseY;         /* 直前のマウスＹ座標 */
	INIT_OBJ(sws);// switch状態を初期化
}
LOCAL void app_init()
{
	ole_init();
	ole_set_area(0, 127, 0, 7);
	ole_clear(0x00);
	pix_init();

	INIT_OBJ(sws);// switch状態を初期化
	sw_task_init();
	ne_obj.data = ch_ptn[0];
}
// switchの状態取得、ラッチ処理、/ nekoの処理への以降の有無を返す
LOCAL B chk_sw(void)
{
	static UB cnt=0;
	//get SW
	UB sw[GP_SW_NUM];
	db_get_val(sw);
	for (int i=0; i<GP_SW_NUM; i++) {
		sw[i] = sw[i] ? 0: 1;
		sws[i] |= sw[i]; //NEKO_INTの間、"1"値を保持する。参照後はRESETする必要あり。
	}
	cnt++;
	if (0 == (cnt % (NEKO_MS/INT_MS))){
		cnt = 0;
		return TRUE;
	}
	return FALSE;
}
LOCAL void menu_disp(UB idx, UB num)
{
	char* name[] = {
			"neko",	"tora",	"dog", "bsd", "sakura", "tomoyo",
	};

	char str[10];
	INIT_OBJ(str);
	tm_sprintf((UB*)str, (UB*)"oneko:%d", idx);
	pix_prt((UB*)str, 7, 0);
	for (int i=0; i<num; i++) {
		INIT_OBJ(str);
		tm_sprintf((UB*)str, (UB*)"%c%s", (i==idx ? '>':' '), name[i]);
		pix_prt((UB*)str, 7, i+2);
	}
	// ole out
	pix_flash();
	pix_write();
}
LOCAL void task_disp(INT stacd, void *exinf)
{
	UB idx = 0;
	app_init();
	//sw[0]がONであれば、menuを起動
	if (0 == gpio_get_val(GP_SW_START)) { //負論理
		UB chnum = sizeof(ch_ptn)/sizeof(unsigned char*);
		menu_disp(idx, chnum);
		while(1) //menu
		{
			tk_slp_tsk(TMO_FEVR);
			chk_sw();
			if (sws[0]) {
				idx++;
				idx %= chnum;
				//SW入力による更新時のみ再度描画する
				menu_disp(idx, chnum);
			}
			if (sws[1]) {
				ne_obj.data = ch_ptn[idx];
				break;
			}
			INIT_OBJ(sws);// switch状態を初期化
		}
	}
	anime_init(&ne_obj, idx);
	while(1) //animation
	{
		tk_slp_tsk(TMO_FEVR);
		if (!chk_sw()) continue;//sws更新のみ
		//neko loop
		NekoThinkDraw(&ne_obj);
		// ole out
		pix_flash();
		pix_write();
	}
	tk_ext_tsk();				// ここは実行されない
}

EXPORT INT usermain(void)
{
	static T_CTSK ctsk_disp = {
		.itskpri	= 10,			// 初期優先度
		.stksz		= 1024,			// スタックサイズ
		.task		= task_disp,		// 実行関数のポインタ
		.tskatr		= TA_HLNG | TA_RNG3,	// タスク属性
	};

	tm_printf((UB*)"User program started\n");

	tskid_disp = tk_cre_tsk(&ctsk_disp);	// タスクの生成
	tk_sta_tsk(tskid_disp, 0);		// タスクの実行

	tk_slp_tsk(TMO_FEVR);			//無限待ち

	return 0;				// ここは実行されない
}
