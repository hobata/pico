/*
 * joy.h
 *
 *  Created on: 2025/02/08
 *      Author: user
 */

#ifndef APP_PROGRAM_JOY_JOY_H_
#define APP_PROGRAM_JOY_JOY_H_

#include <tk/tkernel.h>

extern void js_vec(UW val, int* ret);
extern void get_adc(ID dd_adc, UW* ave);
extern void joy_init(ID *dd_adc);

#endif /* APP_PROGRAM_JOY_JOY_H_ */
