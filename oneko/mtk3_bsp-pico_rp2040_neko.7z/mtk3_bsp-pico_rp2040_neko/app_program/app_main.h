/*
 * app_main.h
 *
 *  Created on: 2025/02/02
 *      Author: user
 */

#ifndef APP_PROGRAM_APP_MAIN_H_
#define APP_PROGRAM_APP_MAIN_H_

#include <bsp/libbsp.h>
#include "oneko/oneko.h"

#define SW_INT			10 //SW状態検出のインターバル
#define INT_MS			100 //SWSの状態チェックのインターバル
#define NEKO_MS			300	//onekoの画作りのインターバル　※INT_MSの倍数
#define GP_SW_START		10	//SW接続最初のGP番号
#define GP_SW_NUM		4	//SWの数

typedef struct ne_obj {
		UB     NekoState;	/* 猫の状態 */
		unsigned char* data;	//キャラクタデータ
		int     NekoLastX;              /* 猫最終描画Ｘ座標 */
		int     NekoLastY;              /* 猫最終描画Ｙ座標 */
		int     NekoX;		/* 猫Ｘ座標 */
		int     NekoY;		/* 猫Ｙ座標 */

		int     NekoTickCount;          /* 猫動作カウンタ */
		int     NekoStateCount;         /* 猫同一状態カウンタ */
		int     NekoMoveDx;             /* 猫移動距離Ｘ */
		int     NekoMoveDy;             /* 猫移動距離Ｙ */

		int     MouseX;                 /* マウスＸ座標 */
		int     MouseY;                 /* マウスＹ座標 */
		int     PrevMouseX;         /* 直前のマウスＸ座標 */
		int     PrevMouseY;         /* 直前のマウスＹ座標 */
		int     IdleSpace;          /*   idle       */
} ne_obj_t;

#endif /* APP_PROGRAM_APP_MAIN_H_ */
