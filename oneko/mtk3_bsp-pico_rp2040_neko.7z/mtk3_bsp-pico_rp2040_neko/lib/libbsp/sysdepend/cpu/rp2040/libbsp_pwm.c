﻿/*
 *----------------------------------------------------------------------
 *    micro T-Kernel 3.0 BSP
 *
 *    Copyright (C) 2022-2023 by Ken Sakamura.
 *    This software is distributed under the T-License 2.2.
 *----------------------------------------------------------------------
 *
 *    Released by TRON Forum(http://www.tron.org) at 2023/05.
 *
 *----------------------------------------------------------------------
 */

/*
 *	libbsp_pwm.c
 *	PWM control (RP2040)
 */

#include <sys/machine.h>
#ifdef CPU_RP2040

#include <tk/tkernel.h>
#include <tm/tmonitor.h>
#include <bsp/libbsp.h>
#include <sys/sysdef.h>

/*----------------------------------------------------------------------*/
/*
 * GPIO Control
 */
#define	PWM_GET_CHNO(port_no)	((port_no>>1)& 0x07)

#define	PWM_CH_CSR(n)		(PWM_BASE + PWM_CHx_CSR + (n*0x14))
#define	PWM_CH_DIV(n)		(PWM_BASE + PWM_CHx_DIV + (n*0x14))
#define	PWM_CH_CTR(n)		(PWM_BASE + PWM_CHx_CTR + (n*0x14))
#define	PWM_CH_CC(n)		(PWM_BASE + PWM_CHx_CC  + (n*0x14))
#define	PWM_CH_TOP(n)		(PWM_BASE + PWM_CHx_TOP + (n*0x14))

ER gpio_set_pin(UINT no, UINT mode)
{
	if(no >= GPIO_NUM) return E_PAR;

	switch(mode) {
	case GPIO_MODE_OUT:
		out_w(GPIO_OE_SET, 1<<no);		// Enable output
		clr_w(GPIO(no), GPIO_IE);		// Disable input
		clr_w(GPIO(no), GPIO_OD);		// Enable output
		break;
	case GPIO_MODE_IN:
		out_w(GPIO_OE_CLR, 1<<no);		// Disable output
		set_w(GPIO(no), GPIO_OD);		// Disable output
		set_w(GPIO(no), GPIO_IE);		// Enable input
		break;
	default:
		return E_PAR;
	}
	out_w(GPIO_CTRL(no), GPIO_CTRL_FUNCSEL_SIO);

	return E_OK;
}

ER gpio_set_val(UINT no, UINT val)
{
	if(no >= GPIO_NUM) return E_PAR;

	if(val > 0) {
		out_w(GPIO_OUT_SET, 1<<no);
	} else {
		out_w(GPIO_OUT_CLR, 1<<no);
	}
	return E_OK;
}

ER gpio_set_oe(UINT no, UINT val)
{
	if(no >= GPIO_NUM) return E_PAR;

	if(val > 0) {
		out_w(GPIO_OE_SET, 1<<no);
	} else {
		out_w(GPIO_OE_CLR, 1<<no);
	}
	return E_OK;
}

ER gpio_set_pad(UINT no, UINT mask, UINT val)
{
	if(no >= GPIO_NUM) return E_PAR;
#if 0
	set_w(GPIO(no), GPIO_IE);			// Enable input
#else
	UW reg_data = in_w(GPIO(no));
	if(val > 0) {
		out_w(GPIO(no), reg_data | mask);
	} else {
		out_w(GPIO(no), reg_data & (~mask));
	}
#endif
	return E_OK;
}

ER gpio_set_ie(UINT no, UINT val)
{
	if(no >= GPIO_NUM) return E_PAR;
#if 0
	set_w(GPIO(no), GPIO_IE);			// Enable input
#else
	UW reg_data = in_w(GPIO(no));
	UW mask = GPIO_IE;
	if(val > 0) {
		out_w(GPIO(no), reg_data | mask);
	} else {
		out_w(GPIO(no), reg_data & (~mask));
	}
#endif
	return E_OK;
}

UINT gpio_get_val(UINT no)
{
	if(no >= GPIO_NUM) return E_PAR;

	return (in_w(GPIO_IN) & 1<<no)?1:0;
}

/*----------------------------------------------------------------------*/
/*
 * PWM Control
 */

ER pwm_set_div(UINT no, UINT div)
{
	if(no >= GPIO_NUM) return E_PAR;
	out_w(PWM_CH_DIV(PWM_GET_CHNO(no)), div << 4);
	//check
	UW reg_val = in_w(PWM_CH_DIV(PWM_GET_CHNO(no)));
	if ( ((reg_val>> 4) & 0xff) != div ) {
		return E_RONLY;
	}
	return E_OK;
}

ER pwm_set_pin(UINT no)
{
	if(no >= GPIO_NUM) return E_PAR;

#if 1 //original
	clr_w(GPIO(no), GPIO_OD);			// Enable output
	set_w(GPIO(no), GPIO_IE);			// Enable input
#else
	gpio_set_pad(no, GPIO_OD, FALSE);	// Enable output
	gpio_set_ie(no, TRUE);				// Enable input
#endif
	/* Reset PWM module*/
	set_w( RESETS_RESET, RESETS_RESET_PWM);
	clr_w( RESETS_RESET, RESETS_RESET_PWM);
	while((in_w(RESETS_RESET_DONE)&(RESETS_RESET_PWM))==0);

	out_w(GPIO_CTRL(no), GPIO_CTRL_FUNCSEL_PWM);	// Set function

	return E_OK;
}

ER pwm_set_wrap(UINT no, UW wrap)
{
	if(no >= GPIO_NUM) return E_PAR;

	out_w(PWM_CH_TOP(PWM_GET_CHNO(no)), wrap);	// Set counter wrap value
	//check
	UW reg_val = in_w(PWM_CH_TOP(PWM_GET_CHNO(no)));
	if ( reg_val != wrap ) {
		return E_RONLY;
	}
	return E_OK;
}

ER pwm_set_cc(UINT no, UW cc)
{
	UINT	ch;
	UW	reg_val;

	if(no >= GPIO_NUM) return E_PAR;

	ch = PWM_GET_CHNO(no);
	reg_val = in_w(PWM_CH_CC(ch));			// Set counter compare value
	if(no & 0x01) {	/* Chan B */
		out_w(PWM_CH_CC(ch), (reg_val & 0x0000FFFF)| (cc<<16));
	} else {	/* Chan A */
		out_w(PWM_CH_CC(ch), (reg_val & 0xFFFF0000)| cc);
	}
	//check
	reg_val = in_w(PWM_CH_CC(ch));
	if(no & 0x01) {	/* Chan B */
		if ( (reg_val>>16) != (cc & 0xffff) ) {
			return E_RONLY;
		}
	} else {	/* Chan A */
		if ( (reg_val & 0xffff) != (cc & 0xffff) ) {
			return E_RONLY;
		}
	}

	return E_OK;
}

ER pwm_init(UINT no)
{
	if(no >= GPIO_NUM) return E_PAR;

	out_w(PWM_CH_CSR(PWM_GET_CHNO(no)), 0);

	UW reg_val = in_w(PWM_CH_CSR(PWM_GET_CHNO(no)));
	if (reg_val != 0) {
		return E_RONLY;
	}
	return	E_OK;
}

ER pwm_set_enabled(UINT no, BOOL enable)
{
	if(no >= GPIO_NUM) return E_PAR;

#if 1 //original
	if(enable) {
		set_w(PWM_CH_CSR(PWM_GET_CHNO(no)), PWM_CH_CSR_EN);	// Enable chanel
	} else {
		clr_w(PWM_CH_CSR(PWM_GET_CHNO(no)), PWM_CH_CSR_EN);	// Disable chanel
	}
#else
	UINT ch = PWM_GET_CHNO(no);
	UW reg_val = in_w(PWM_EN);
	if(enable) {
		reg_val |= (PWM_CH_CSR_EN << ch);
		out_w(PWM_EN, reg_val);
	} else {
		reg_val &= ~(PWM_CH_CSR_EN << ch);
		out_w(PWM_EN, reg_val);
	}
#endif
	return	E_OK;
}

#endif /* CPU_RP2040 */
