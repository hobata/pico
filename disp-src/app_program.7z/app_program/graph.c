/*
 * graph.c
 *
 *  Created on: 2024/12/07
 *      Author: user
 */
#include <tk/tkernel.h>

BOOL g_area[128][64];

#define rep(i, n) for (int i=0; i < (n); i++)
//void *memset(void *s, int c, size_t n);

void graph_init(void)
{
	memset(g_area, FALSE, sizeof(g_area));
}

void graph_set(int x, int y, int xsize, int ysize, char* ptr)
{
	for (int i=x; i < x + xsize; i++) {
		for (int j=y; j < y + ysize; j++) {
			g_area[i][j] = ptr[i + j * xsize] == 'O' ? TRUE:FALSE;
		}
	}
}
UB* graph_get(void)
{
	static UB b[128][8];
    rep(i, 128) {
        rep(j, 8) {
        	b[i][j] = 0;
        	rep(k, 8) {
        		b[i][j] |= g_area[i][j*8+k] ? (1<<k):0;
        	}

        }
    }
	return b;
}
