#include <tk/tkernel.h>
#include <tk/device.h>		// デバイスドライバ定義ファイル
#include <tm/tmonitor.h>
#include <bsp/libbsp.h>

#include <stdint.h>
#include "ole.h"
#include "./gpio/address_mapped.h"
#include "./gpio/addressmap.h"

extern const uint8_t font_prm[];
extern const char dummy[8][11];
extern const char *src_dump[];
extern const UW	src_dump_size;

UW get_random(void)
{
	UW val = 0;
	for (int i=0; i<20; i++) {
	  val |= (*(io_rw_32 *)(ROSC_BASE | 0x1c)) & 1;
	  val <<= 1;
	}
	return val;
}

/* usermain関数 */
EXPORT INT usermain(void)
{
	ole_init();
	ole_set_area(0, 127, 0, 7);
	ole_clear(0x00);

	int lines = src_dump_size;
	int cnt = 0;
	ole_set_area(1, 126, 1, 7); //文字表示向けエリア指定
	while(1) {
      for (int i = 0 ; i < lines; i++) {
    	  if (cnt == 0 ) {
#if 0
    		  i = (int)(get_random() % (UW)lines);
#else
    		  // nothing to do = start 1st line
#endif
    		  }
    	  int linecnt = 0; //　characters in a line
    	  //print byte
    	  if ((i % 5 == 0) || (cnt ==0)) {
    		  ole_set_area(1, 126, 0, 0); //TOP行のエリア指定
    		  if (cnt != 0) {
    			  tk_slp_tsk(3000);
    		  }
    		  char num[] = "L:00000, B:000000000";
			  int line2 = i;
    		  for (int j=6; j >= 2; j--) {
    			  if (line2 == 0) break;
    			  num[j] = '0' + (line2 % 10);
    			  line2 /= 10;
    		  }
    		  int cnt2 = cnt;
    		  for (int j=19; j >= 11; j--) {
    			  if (cnt2 == 0) break;
    			  num[j] = '0' + (cnt2 % 10);
    			  cnt2 /=10;
    		  }
    		  ole_prt(num, sizeof(num));
        	  ole_set_area(1, 126, 1, 7); //ソース表示のエリア指定
    	  }
    	  //source
		  char *str = (char*)src_dump[i];
		  char temp;
		  int flag = 0;
		  while(1) {//one line
			  temp = *str;
			  if (temp == 0x9) temp = 0x20; //TAB->SPC
			  while(temp < 0x20 || temp > 0x7e) { //escape char or not suuported
				  if (temp == 0x0) { // end of str
				    flag = 1;
				    break;
				  }
  			      str++; cnt++;
			      temp = *str;
			  }
		  	  if (flag) break;
		  	  ole_prt(&temp, sizeof(temp));
		  	  linecnt++;
		  	  tk_slp_tsk(50);
		  	  str++; cnt++;
		  }
		  //表示行末から、表示枠の右端までスペースで埋める
		  char spc[22] = "                     ";
	  	  int spcnum = 21 - (linecnt % 21);
	  	  if (spcnum != 21) {
	  		  ole_prt(spc, spcnum);
	  	  }
	   }
	}

	tk_slp_tsk(TMO_FEVR);

	return 0;				// ここは実行されない
}
