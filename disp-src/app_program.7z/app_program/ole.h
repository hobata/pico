/*
 * ole.h
 *
 *  Created on: 2024/12/07
 *      Author: user
 */
#include "ssd1306_ini.h"

#ifndef APP_PROGRAM_OLE_H_
#define APP_PROGRAM_OLE_H_

ER ole_snd_cmd(UB* snd_data, UB len);
void ole_init(void);
ER ole_scroll_vh_r(BOOL right, UB spage, UB epage, UB step, UB offset);
ER ole_scroll_h_r(BOOL right, UB spage, UB epage, UB step);
void ole_clear(UB ptn);
void ole_clear_size(UB ptn, UW len);
void ole_set_area(UB x1, UB x2, UB y1, UB y2);
void ole_prt(char* c, UB len);

#endif /* APP_PROGRAM_OLE_H_ */
