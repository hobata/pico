#!/bin/sh

find /mnt/c/Users/user/eclipse-workspace/uT-Kernel/mtk3_bsp-pico_rp2040/mtk3_bsp-pico_rp2040/ -name "*.h" > filelist.txt
find /mnt/c/Users/user/eclipse-workspace/uT-Kernel/mtk3_bsp-pico_rp2040/mtk3_bsp-pico_rp2040/ -name "*.c" >> filelist.txt

cat filelist.txt | grep -v dump.c | grep -v nucleo_l476 | grep -v iote_m367 | grep -v nucleo_h723 | grep -v rsk_rz65n | grep -v rx231 | grep -v rx65n | grep -v rza2m | grep -v stm32h7 | grep -v stm32l4 | grep -v tx03_m367 > filelist2.txt
rm filelist.txt

# windows:\\r
cat filelist2.txt | sort | xargs tail -n +1 | sed -e 's/==> \/mnt\/c\/Users\/user\/eclipse-workspace\/uT-Kernel\/mtk3_bsp-pico_rp2040\/mtk3_bsp-pico_rp2040\///g' | sed -e 's/ <==//g' | sed 's/\\/\\\\/g' | sed 's/\"/\\\"/g' |  tr -d \\r > dump.txt
#cat filelist2.txt | sort | xargs tail -n +1 | sed 's/\\/\\\\/g' | sed 's/\"/\\\"/g' |  tr -d \\r > dump.txt
#cat filelist2.txt | sort | xargs cat | sed 's/\\/\\\\/g' | sed 's/\"/\\\"/g' |  tr -d \\r > dump.txt

cat head.txt > dump.c
cat dump.txt | sed -e 's/$/\",/' | sed -e 's/^/\"/' >> dump.c
cat footer.txt >> dump.c
