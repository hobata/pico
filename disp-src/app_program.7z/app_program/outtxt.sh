#!/bin/sh

find /mnt/c/Users/user/eclipse-workspace/uT-Kernel/mtk3_bsp-pico_rp2040/ -name "*.h" > filelist.txt
find /mnt/c/Users/user/eclipse-workspace/uT-Kernel/mtk3_bsp-pico_rp2040/ -name "*.c" | grep -v dump >> filelist.txt
#find /mnt/c/Users/user/eclipse-workspace/uT-Kernel/mtk3_bsp-pico_rp2040/ -name "*.mk" >> filelist.txt
# windows:\\r
cat filelist.txt | sort | xargs cat | sed 's/\\/\\\\/g' | sed 's/\"/\\\"/g' |  tr -d \\r > dump.txt
# // converter
cat dump.txt | sed -e 's/$/\",/' | sed -e 's/^/\"/' > dump.c
#cat dump.txt | sed -e 's/$/\"\},/' | sed -e 's/^/\{\"/' > dump.c

